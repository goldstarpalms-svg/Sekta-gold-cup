"""Setka prediction app package."""
